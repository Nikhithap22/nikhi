sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller){
	"use strict";
	//We define the app controller in its own file by extending the controller object of the SAPUI5 core.
	return Controller.extend("sap.ui.odata.conn.demo.controller.App", {
		onInit : function(){
			
		}
	});
});