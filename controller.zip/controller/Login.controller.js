sap.ui.define([
               'sap/ui/core/mvc/Controller',
               "sap/m/MessageBox","sap/ui/model/Filter"
], function(Controller, MessageBox,Filter){
	"use strict";
	return Controller.extend("sap.ui.odata.conn.demo.controller.Login", {
		onInit : function(){			
		//	debugger;
			this.oODataModel = this.getOwnerComponent().getModel("MODEL");
			
		},
	handleCancelPress:function()
	{
	//	debugger;
	//	var oDataModel = sap.ui.getCore().getModel('getEmpModel');
		
		var that = this;
		this.oODataModel.read('/Employees',{
			success: function(oData,oResponse) 
			{					
				//debugger;
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(oResponse.data.results);													
				that.getView().byId("idUnit").setModel(oModel, "UnitSiteModel");
				that.getView().byId("idUnit1").setModel(oModel, "UnitSiteModel");
				that.getView().byId("idProductsTable").setModel(oModel, "UnitSiteModel");
				that.getView().byId("idProductsTable").setVisible(true);
			
			},
			error: function(oError) 
			{
				//debugger;

			}
			
		});
		
		

	},
	onSiteChange:function()
	{
		debugger;
		this.getView().byId('idUnit').getSelectedKey();
	},
	onSelect:function(oEvent)
	{
		this.inputId = oEvent.getSource().getId();
		if (!this._odeliveryClubSelectDialog3) {
			this._odeliveryClubSelectDialog3 = sap.ui.xmlfragment("sap.ui.odata.conn.demo.fragments.DeliveryClub_ValueHelp", this);
			this._odeliveryClubSelectDialog3.setModel(this.oODataModel);
		}
		this._odeliveryClubSelectDialog3.open();
	},
	onSelect2:function(oEvent)
	{
		this.inputId = oEvent.getSource().getId();
		if (!this._odeliveryClubSelectDialog1) {
			this._odeliveryClubSelectDialog1 = sap.ui.xmlfragment("sap.ui.odata.conn.demo.fragments.lastName_Select", this);
			this._odeliveryClubSelectDialog1.setModel(this.oODataModel);
		}
		this._odeliveryClubSelectDialog1.open();
	},
	onSelect3:function(oEvent)
	{
		this.inputId = oEvent.getSource().getId();
		if (!this._odeliveryClubSelectDialog2) {
			this._odeliveryClubSelectDialog2 = sap.ui.xmlfragment("sap.ui.odata.conn.demo.fragments.address_select", this);
			this._odeliveryClubSelectDialog2.setModel(this.oODataModel);
		}
		this._odeliveryClubSelectDialog2.open();
	},
	
	_odeliveryClubValueHelpClose: function(evt) {
		debugger;
		var oSelectedItem = evt.getParameter("selectedItem");
		if (oSelectedItem) {
			var productInput = this.getView().byId(this.inputId);
			productInput.setValue(oSelectedItem.getTitle());
		}
		evt.getSource().getBinding("items").filter([]);
		
	},
	_odeliveryClubValueHelpSearch: function(evt) {
		debugger;
		var sValue = evt.getParameter("value");
		var oFilter = new Filter(
			"Class",
			sap.ui.model.FilterOperator.Contains, sValue
		);
		evt.getSource().getBinding("items").filter([oFilter]);
	},
	handleValueHelp:function()
	{
		alert("");
	},
	onChangeDate:function(){
		alert();
	},
	/*onSelectionChange:function(){
		var items=this.getView().byId("idProductsTable")._aSelectedPaths[0];
		items=items.charAt(1);
		var len=this.getView().byId("idProductsTable").getSelectedItems().length;
		for(var i=1;i<len;i++)
			{
			var temp=this.getView().byId("idProductsTable")._aSelectedPaths[i];
			items=items+","+ temp.charAt(1);
			}
		alert(items);
	},*/
	handleInfoPress:function(){
		
		var items=this.getView().byId("idProductsTable")._aSelectedPaths[0];
		items=items.charAt(1);
		var code=this.getView().byId("idProductsTable").oModels.UnitSiteModel.getData()[items].PostalCode;
		
		var len=this.getView().byId("idProductsTable").getSelectedItems().length;
		for(var i=1;i<len;i++)
			{
			var temp=this.getView().byId("idProductsTable")._aSelectedPaths[i];
			temp=temp.charAt(1);
			var codeTemp=this.getView().byId("idProductsTable").oModels.UnitSiteModel.getData()[temp].PostalCode;
			//items=items+","+ temp;
			code=code+"\n"+codeTemp;
			//this.getView().byId("idProductsTable").oModels.UnitSiteModel.getData()[temp];
			}
		
		
		sap.m.MessageBox.information(code, {
		    title: "Information",                                // default
		    onClose: null   ,                                     // default
		    styleClass: ""  ,                                     // default
		    initialFocus: null  ,                                 // default
		    textDirection: sap.ui.core.TextDirection.Inherit     // default
		    });
	},
	
	handleSavePress:function(oEvent){
		var len=this.getView().byId("idUnit1").getSelectedItems().length;
		var selection=this.getView().byId("idUnit1").getSelectedItems()[0].getText();
		//alert(selection);
		var temp=" ";
		//alert(temp);
		for(var i=1;i<len;i++){
			temp=this.getView().byId("idUnit1").getSelectedItems()[i].getText();
			selection+=" ," +temp;
		}
		//alert(selection);
		//var selection=this.getView().byId("idUnit1").getSelectedItems();
		
		//alert(selection);
		//MessageBox.information(selection);
		
	sap.m.MessageBox.information(selection, {
		    title: "Information",                                // default
		    onClose: null   ,                                     // default
		    styleClass: ""  ,                                     // default
		    initialFocus: null  ,                                 // default
		    textDirection: sap.ui.core.TextDirection.Inherit     // default
		    });
	}
		
	});
});